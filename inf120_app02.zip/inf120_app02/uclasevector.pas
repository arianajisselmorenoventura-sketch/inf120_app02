unit uClaseVector;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Dialogs;

const
  MAX_E = 1000;

type

  { Vector }

  Vector = class
  private
    elem: array[1..MAX_E] of Integer;
    dim: Integer;
    procedure QuickSortHelper(ini, fin: Integer);
  public
    constructor Create;

    // Operaciones requeridas por la guía
    procedure Cargar(n, a, b: Integer);
    function Mostrar: string;
    procedure Adicionar(e: Integer);
    procedure Insertar(pos, e: Integer);
    function Obtener(pos: Integer): Integer;
    function Cantidad: Integer;
    procedure Invertir;
    procedure Rotar;
    function BusquedaSecuencial(e: Integer): Integer;
    function BusquedaBinaria(e: Integer): Integer;

    // Algoritmos de Ordenamiento
    procedure OrdenarInsercion;
    procedure OrdenarSeleccion;
    procedure OrdenarIntercambio;
    procedure OrdenarBurbuja;
    procedure OrdenarQuicksort;

    // Operaciones adicionales de la guía
    procedure EliminarRep;
    procedure OrdenarFrec;
    function ComoString: string;
    procedure EliminarPos(pos: Integer);   //Ctrl+SHIFT+C
  end;

implementation

constructor Vector.Create;
begin
  dim := 0;
end;

// Cargar N elementos aleatorios entre el rango [a, b]
procedure Vector.Cargar(n, a, b: Integer);
var
  i: Integer;
begin
  dim := n;
  Randomize;
  for i := 1 to dim do
    elem[i] := Random(b - a + 1) + a;
end;

// Mostrar representación en cadena
function Vector.Mostrar: string;
begin
  Result := ComoString;
end;

// Adicionar elemento al final
procedure Vector.Adicionar(e: Integer);
begin
  if dim < MAX_E then
  begin
    Inc(dim);
    elem[dim] := e;
  end
  else
    ShowMessage('Vector Lleno');
end;

// Insertar elemento en una posición específica
procedure Vector.Insertar(pos, e: Integer);
var
  i: Integer;
begin
  if (pos >= 1) and (pos <= dim + 1) and (dim < MAX_E) then
  begin
    for i := dim downto pos do
      elem[i + 1] := elem[i];
    elem[pos] := e;
    Inc(dim);
  end;
end;

// Obtener valor de la posición
function Vector.Obtener(pos: Integer): Integer;
begin
  if (pos >= 1) and (pos <= dim) then
    Result := elem[pos]
  else
    Result := -999;
end;

// Devolver la cantidad actual de elementos
function Vector.Cantidad: Integer;
begin
  Result := dim;
end;

// Invertir los elementos del vector
procedure Vector.Invertir;
var
  i, aux: Integer;
begin
  for i := 1 to dim div 2 do
  begin
    aux := elem[i];
    elem[i] := elem[dim - i + 1];
    elem[dim - i + 1] := aux;
  end;
end;

// Rotar a la derecha
procedure Vector.Rotar;
var
  i, aux: Integer;
begin
  if dim > 1 then
  begin
    aux := elem[dim];
    for i := dim downto 2 do
      elem[i] := elem[i - 1];
    elem[1] := aux;
  end;
end;

// Búsqueda Secuencial (retorna la posición o 0 si no encuentra)
function Vector.BusquedaSecuencial(e: Integer): Integer;
var
  i: Integer;
begin
  Result := 0;
  for i := 1 to dim do
  begin
    if elem[i] = e then
    begin
      Result := i;
      Exit;
    end;
  end;
end;

// Búsqueda Binaria (requiere que el vector esté previamente ordenado)
function Vector.BusquedaBinaria(e: Integer): Integer;
var
  ini, fin, medio: Integer;
begin
  Result := 0;
  ini := 1;
  fin := dim;
  while ini <= fin do
  begin
    medio := (ini + fin) div 2;
    if elem[medio] = e then
      Exit(medio)
    else if elem[medio] < e then
      ini := medio + 1
    else
      fin := medio - 1;
  end;
end;

// Ordenamiento por Inserción
procedure Vector.OrdenarInsercion;
var
  i, j, aux: Integer;
begin
  for i := 2 to dim do
  begin
    aux := elem[i];
    j := i - 1;
    while (j > 0) and (elem[j] > aux) do
    begin
      elem[j + 1] := elem[j];
      Dec(j);
    end;
    elem[j + 1] := aux;
  end;
end;

// Ordenamiento por Selección
procedure Vector.OrdenarSeleccion;
var
  i, j, min, aux: Integer;
begin
  for i := 1 to dim - 1 do
  begin
    min := i;
    for j := i + 1 to dim do
      if elem[j] < elem[min] then
        min := j;
    aux := elem[i];
    elem[i] := elem[min];
    elem[min] := aux;
  end;
end;

// Ordenamiento por Intercambio
procedure Vector.OrdenarIntercambio;
var
  i, j, aux: Integer;
begin
  for i := 1 to dim - 1 do
    for j := i + 1 to dim do
      if elem[i] > elem[j] then
      begin
        aux := elem[i];
        elem[i] := elem[j];
        elem[j] := aux;
      end;
end;

// Ordenamiento por Burbuja
procedure Vector.OrdenarBurbuja;
var
  i, j, aux: Integer;
begin
  for i := 1 to dim - 1 do
    for j := 1 to dim - i do
      if elem[j] > elem[j + 1] then
      begin
        aux := elem[j];
        elem[j] := elem[j + 1];
        elem[j + 1] := aux;
      end;
end;

// Auxiliar para Quicksort
procedure Vector.QuickSortHelper(ini, fin: Integer);
var
  i, j, pivote, aux: Integer;
begin
  i := ini;
  j := fin;
  pivote := elem[(ini + fin) div 2];
  repeat
    while elem[i] < pivote do Inc(i);
    while elem[j] > pivote do Dec(j);
    if i <= j then
    begin
      aux := elem[i];
      elem[i] := elem[j];
      elem[j] := aux;
      Inc(i);
      Dec(j);
    end;
  until i > j;
  if ini < j then QuickSortHelper(ini, j);
  if i < fin then QuickSortHelper(i, fin);
end;

// Ordenamiento Quicksort
procedure Vector.OrdenarQuicksort;
begin
  if dim > 1 then
    QuickSortHelper(1, dim);
end;

// Eliminar elementos repetidos
procedure Vector.EliminarRep;
var
  i, j, k: Integer;
begin
  i := 1;
  while i <= dim do
  begin
    j := i + 1;
    while j <= dim do
    begin
      if elem[i] = elem[j] then
      begin
        for k := j to dim - 1 do
          elem[k] := elem[k + 1];
        Dec(dim);
      end
      else
        Inc(j);
    end;
    Inc(i);
  end;
end;

// Ordenar por Frecuencia de aparición
procedure Vector.OrdenarFrec;
var
  i, j, fI, fJ, aux: Integer;

  function ContarFrecuencia(e: Integer): Integer;
  var
    k, c: Integer;
  begin
    c := 0;
    for k := 1 to dim do
      if elem[k] = e then Inc(c);
    Result := c;
  end;

begin
  for i := 1 to dim - 1 do
  begin
    for j := i + 1 to dim do
    begin
      fI := ContarFrecuencia(elem[i]);
      fJ := ContarFrecuencia(elem[j]);
      if (fI < fJ) or ((fI = fJ) and (elem[i] > elem[j])) then
      begin
        aux := elem[i];
        elem[i] := elem[j];
        elem[j] := aux;
      end;
    end;
  end;
end;

// Formato ComoString [x, y, z]
function Vector.ComoString: string;
var
  i: Integer;
  s: string;
begin
  s := '[';
  for i := 1 to dim do
  begin
    s := s + IntToStr(elem[i]);
    if i < dim then
      s := s + ', ';
  end;
  s := s + ']';
  Result := s;
end;

procedure Vector.EliminarPos(pos: Integer);
var
  i: Integer;
begin
  if (pos >= 1) and (pos <= dim) then
  begin
    for i := pos to dim - 1 do
      elem[i] := elem[i + 1];
    Dec(dim);
  end
  else
    ShowMessage('Posición fuera de rango');
end;

end.
