unit uVector;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Grids, Menus, uClaseVector;

type

  { TForm1 }

  TForm1 = class(TForm)
    MainMenu1: TMainMenu;

    // Menús principales
    MenuItemMetodos: TMenuItem;
    MenuItemOrdenamiento: TMenuItem;

    // Opciones del Menú Métodos
    MenuCrear: TMenuItem;
    MenuCargar: TMenuItem;
    MenuMostrar: TMenuItem;
    MenuAdicionar: TMenuItem;
    MenuInsertar: TMenuItem;
    MenuObtener: TMenuItem;
    MenuCantidad: TMenuItem;
    MenuInvertir: TMenuItem;
    MenuRotar: TMenuItem;
    MenuBusqSecuencial: TMenuItem;
    MenuBusqBinaria: TMenuItem;
    MenuEliminarRep: TMenuItem;
    MenuOrdenarFrec: TMenuItem;
    MenuComoString: TMenuItem;

    // Opciones del Menú Ordenamientos
    MenuOrdInsercion: TMenuItem;
    MenuOrdSeleccion: TMenuItem;
    MenuOrdIntercambio: TMenuItem;
    MenuOrdBurbuja: TMenuItem;
    MenuOrdQuicksort: TMenuItem;

    // Componentes visuales
    Edit1: TEdit; // Para Valor / N
    Edit2: TEdit; // Para Posición / Mínimo
    Edit3: TEdit; // Para Máximo
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    StringGrid1: TStringGrid;

    procedure FormCreate(Sender: TObject);
    procedure MenuCrearClick(Sender: TObject);
    procedure MenuCargarClick(Sender: TObject);
    procedure MenuMostrarClick(Sender: TObject);
    procedure MenuAdicionarClick(Sender: TObject);
    procedure MenuInsertarClick(Sender: TObject);
    procedure MenuObtenerClick(Sender: TObject);
    procedure MenuCantidadClick(Sender: TObject);
    procedure MenuInvertirClick(Sender: TObject);
    procedure MenuRotarClick(Sender: TObject);
    procedure MenuBusqSecuencialClick(Sender: TObject);
    procedure MenuBusqBinariaClick(Sender: TObject);
    procedure MenuOrdInsercionClick(Sender: TObject);
    procedure MenuOrdSeleccionClick(Sender: TObject);
    procedure MenuOrdIntercambioClick(Sender: TObject);
    procedure MenuOrdBurbujaClick(Sender: TObject);
    procedure MenuOrdQuicksortClick(Sender: TObject);
    procedure MenuEliminarRepClick(Sender: TObject);
    procedure MenuOrdenarFrecClick(Sender: TObject);
    procedure MenuComoStringClick(Sender: TObject);

  private
    procedure ActualizarGrid;
  public

  end;

var
  Form1: TForm1;
  v: Vector;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.ActualizarGrid;
var
  i: Integer;
begin
  if Assigned(v) and (v.Cantidad > 0) then
  begin
    StringGrid1.ColCount := v.Cantidad;
    StringGrid1.RowCount := 1;
    StringGrid1.FixedCols := 0;
    StringGrid1.FixedRows := 0;
    for i := 1 to v.Cantidad do
      StringGrid1.Cells[i - 1, 0] := IntToStr(v.Obtener(i));
  end
  else
  begin
    StringGrid1.ColCount := 1;
    StringGrid1.RowCount := 1;
    StringGrid1.FixedCols := 0;
    StringGrid1.FixedRows := 0;
    StringGrid1.Cells[0, 0] := '';
  end;
end;

procedure TForm1.MenuCrearClick(Sender: TObject);
begin
  v := Vector.Create;
  ActualizarGrid;
  ShowMessage('Vector Creado Exitosamente');
end;

procedure TForm1.FormCreate(Sender: TObject);
begin

end;

procedure TForm1.MenuCargarClick(Sender: TObject);
begin
  if Assigned(v) and (Edit1.Text <> '') and (Edit2.Text <> '') and (Edit3.Text <> '') then
  begin
    v.Cargar(StrToInt(Edit1.Text), StrToInt(Edit2.Text), StrToInt(Edit3.Text));
    ActualizarGrid;
  end
  else
    ShowMessage('Use Edit1 para N, Edit2 para Mínimo y Edit3 para Máximo.');
end;

procedure TForm1.MenuMostrarClick(Sender: TObject);
begin
  if Assigned(v) then
    ShowMessage('Vector: ' + v.Mostrar);
end;

procedure TForm1.MenuAdicionarClick(Sender: TObject);
begin
  if Assigned(v) and (Edit1.Text <> '') then
  begin
    v.Adicionar(StrToInt(Edit1.Text));
    ActualizarGrid;
    Edit1.Clear;
  end;
end;

procedure TForm1.MenuInsertarClick(Sender: TObject);
begin
  if Assigned(v) and (Edit1.Text <> '') and (Edit2.Text <> '') then
  begin
    v.Insertar(StrToInt(Edit2.Text), StrToInt(Edit1.Text));
    ActualizarGrid;
  end;
end;

procedure TForm1.MenuObtenerClick(Sender: TObject);
begin
  if Assigned(v) and (Edit2.Text <> '') then
    ShowMessage('Elemento en pos ' + Edit2.Text + ': ' + IntToStr(v.Obtener(StrToInt(Edit2.Text))));
end;

procedure TForm1.MenuCantidadClick(Sender: TObject);
begin
  if Assigned(v) then
    ShowMessage('Cantidad de elementos: ' + IntToStr(v.Cantidad));
end;

procedure TForm1.MenuInvertirClick(Sender: TObject);
begin
  if Assigned(v) then
  begin
    v.Invertir;
    ActualizarGrid;
  end;
end;

procedure TForm1.MenuRotarClick(Sender: TObject);
begin
  if Assigned(v) then
  begin
    v.Rotar;
    ActualizarGrid;
  end;
end;

procedure TForm1.MenuBusqSecuencialClick(Sender: TObject);
var
  p: Integer;
begin
  if Assigned(v) and (Edit1.Text <> '') then
  begin
    p := v.BusquedaSecuencial(StrToInt(Edit1.Text));
    if p > 0 then
      ShowMessage('Encontrado en la posición: ' + IntToStr(p))
    else
      ShowMessage('Elemento No Encontrado');
  end;
end;

procedure TForm1.MenuBusqBinariaClick(Sender: TObject);
var
  p: Integer;
begin
  if Assigned(v) and (Edit1.Text <> '') then
  begin
    p := v.BusquedaBinaria(StrToInt(Edit1.Text));
    if p > 0 then
      ShowMessage('Encontrado en la posición: ' + IntToStr(p))
    else
      ShowMessage('Elemento No Encontrado (Asegúrese de ordenar el vector primero)');
  end;
end;

procedure TForm1.MenuOrdInsercionClick(Sender: TObject);
begin
  if Assigned(v) then
  begin
    v.OrdenarInsercion;
    ActualizarGrid;
  end;
end;

procedure TForm1.MenuOrdSeleccionClick(Sender: TObject);
begin
  if Assigned(v) then
  begin
    v.OrdenarSeleccion;
    ActualizarGrid;
  end;
end;

procedure TForm1.MenuOrdIntercambioClick(Sender: TObject);
begin
  if Assigned(v) then
  begin
    v.OrdenarIntercambio;
    ActualizarGrid;
  end;
end;

procedure TForm1.MenuOrdBurbujaClick(Sender: TObject);
begin
  if Assigned(v) then
  begin
    v.OrdenarBurbuja;
    ActualizarGrid;
  end;
end;

procedure TForm1.MenuOrdQuicksortClick(Sender: TObject);
begin
  if Assigned(v) then
  begin
    v.OrdenarQuicksort;
    ActualizarGrid;
  end;
end;

procedure TForm1.MenuEliminarRepClick(Sender: TObject);
begin
  if Assigned(v) then
  begin
    v.EliminarRep;
    ActualizarGrid;
  end;
end;

procedure TForm1.MenuOrdenarFrecClick(Sender: TObject);
begin
  if Assigned(v) then
  begin
    v.OrdenarFrec;
    ActualizarGrid;
  end;
end;

procedure TForm1.MenuComoStringClick(Sender: TObject);
begin
  if Assigned(v) then
    ShowMessage('ComoString: ' + v.ComoString);
end;

end.
